package ArrayArrayList;

import java.util.Arrays;

public class PassingInFunctions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num= {3,4,5,12};
		System.out.println(Arrays.toString(num));
		// change(num);
		System.out.println(Arrays.toString(num));
//	    static void change(int[] arr)
//		{
//			arr[0]=1;
//		}

	}

}
