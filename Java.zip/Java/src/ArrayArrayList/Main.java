package ArrayArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] RollNo = new int[5];
		int[] rollno1; // declaration of array getting assigned in stack
		rollno1 = new int[5];// initialization:creating object in in heap memory
								// Dynamic memory allocation : assigning memory space at run time
		System.out.println(RollNo[0]);
		String[] arr = new String[5];
		System.out.println(arr[0]);

	}

}
