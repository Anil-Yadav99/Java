package ArrayArrayList;

public class MaximumItem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 3, 12, 8, 9 };
		System.out.println(Maximum(arr));

	}

	static int Maximum(int[] arr) {
		int max = arr[0];
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > max) {
				max = arr[i];
			}

		}
		return max;
	}
}
