package ArrayArrayList;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListExample {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		ArrayList<Integer> list = new ArrayList<>();
//		list.add(01);
//		list.add(10);
//		list.add(30);
//		list.add(25);
//		list.add(0, 30);
//		list.set(1, 99);
//		list.remove(1);
//		System.out.println(list);

		// input

		for (int i = 0; i <= 5; i++) {
			list.add(sc.nextInt());
		}
		// get item at any index
		for (int i = 0; i <= 5; i++) {
			System.out.println(list.get(i));// list.index not worked here
		}
	}

}
