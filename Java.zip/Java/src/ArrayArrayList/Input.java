package ArrayArrayList;

import java.util.Arrays;
import java.util.Scanner;

public class Input {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		int[] arr = new int[5];
//		arr[0] = 23;
//		arr[1] = 45;
//		arr[2] = 45;
//		arr[3] = 45;
//		arr[4] = 45;

		// [23,45,45,45,45,]
		// System.out.println(arr[3]);

		// input using for loop
//		System.out.println("Enter Element of Array");
//		for (int i = 0; i < arr.length; i++) {
//
//			arr[i] = in.nextInt();
//		}
//
//		for (int i = 0; i < arr.length; i++) {
//
//			System.out.print(arr[i] + "");
//		}
//		System.out.println("\n1");
//		for (int num : arr) {
//			System.out.print(num + "");
//		}
//		System.out.println("\n");
//		System.out.println(Arrays.toString(arr));
		String[] str = new String[4];
		for (int i = 0; i < str.length; i++) {
			str[i] = in.nextLine();
		}

		// modify
		str[1] = "Anil";
		str[2] = "Jyoti";
		System.out.println(Arrays.toString(str));
	}

}
