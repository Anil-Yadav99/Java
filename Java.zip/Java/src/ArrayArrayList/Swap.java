package ArrayArrayList;

import java.util.Arrays;

public class Swap {
	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4, 5, 6, 7 };
//		swap(arr, 0, 3);
//		System.out.println(Arrays.toString(arr));
		reverse(arr);
		System.out.print(Arrays.toString(arr));
	}

	public static void swap(int[] arr, int Index1, int Index2) {
		int temp = arr[Index1];
		arr[Index1] = arr[Index2];
		arr[Index2] = temp;
	}

	public static void reverse(int[] arr) {
		int start = 0;
		int last = arr.length-1;
		while (start < last) {
			swap(arr, start, last);
			start++;
			last--;
		}
	}
}
