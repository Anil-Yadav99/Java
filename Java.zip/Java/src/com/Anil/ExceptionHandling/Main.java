package com.Anil.ExceptionHandling;

public class Main {

	public static void main(String[] args) throws MyException {
		int a = 5;
		int b = 0;
		String name = "Jyoti";

		try
		{
				if (name.equals("Jyoti")) {
					throw new MyException("Name Cant be Jyoti");
				}
			devide(a,b);
			}
			catch (MyException e) {
				System.out.println(e.getMessage());
			}
		catch (ArithmeticException e)
			{
				System.out.println(e.getMessage());
			}
			catch (Exception e) {
				System.out.println("Normal Exception");
			}
		finally
			{
				System.out.println("This will Always execute");
			}
		}

		static int devide(int a, int b) throws ArithmeticException {
			if (b == 0) {
				throw new ArithmeticException("Cant devide by zero");
			}
			return a / b;
		}

}

