package com.Anil.ExceptionHandling;

public class MyException extends Exception {

	public MyException(String Message) {
		super(Message);
	}


}
