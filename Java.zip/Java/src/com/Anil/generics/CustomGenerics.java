package com.Anil.generics;

import java.util.Arrays;

public class CustomGenerics<T> {

	private Object[] data;
	private static int DEFAULT_SIZE = 10;
	private int size = 0;// also working as index number

	CustomGenerics() {
		this.data = new Object[DEFAULT_SIZE];
	}

	public void add(T num) {
		if (isFull()) {
			resize();
		}
		data[size++] = num;
	}

	private void resize() {
		Object[] temp = new Object[data.length * 2];

		for (int i = 0; i < data.length; i++) {
			temp[i] = data[i];
		}
		data = temp;
	}

	private boolean isFull() {
		return size == data.length;
	}

	public T remove() {
		T removed = (T) (data[--size]);
		return removed;
	}

	public T get(int index) {
		return (T) data[index];
	}

	public int size() {
		return size;
	}

	public void set(int index, T value) {
		data[index] = value;
	}

	@Override
	public String toString() {
		return String.format("CustomGenerics [data=%s, size=%s]", Arrays.toString(data), size);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomGenerics<Integer> list = new CustomGenerics();
		list.add(3);
		list.add(5);
		list.add(10);
		System.out.println(list);
	}

	}

