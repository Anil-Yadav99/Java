package com.Anil.Abstract;

class HR extends Employee {

	@Override
	void printSalary() {
		System.out.println("printing the salary....");
	}
}

