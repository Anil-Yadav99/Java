package com.Anil.Abstract;

abstract class Employee {
	// constructor of the vehicle class
	Employee() {
		System.out.println("Employee is created");

	}

	// abstract method
	abstract void printSalary();

	// non-abstract method
	void designationUpdate() {
		System.out.println("Designation will be updated soon");

	}
}
