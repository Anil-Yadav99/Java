package com.Anil.Abstract;

public class Runner {

	// class calling the abstract and non-abstract methods
	public static void main(String args[]) {
		Employee obj = new HR();
		obj.printSalary();
		obj.designationUpdate();
	}
	}

