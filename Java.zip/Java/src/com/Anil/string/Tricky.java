package com.Anil.string;

public class Tricky {

	public static void main(String[] args) {
//		String s1 = "coding";
//		StringBuffer s2 = new StringBuffer(s1);
//		System.out.println(s1.equals(s2)); // FALSE
//
//		String s1 = new String("coding");
//		String s2 = new String("CODING");
//		System.out.println(s1 = s2);  //CODING

//		System.out.println('c' + 'o' + 'd' + 'e');

		{
			String s1 = "codingninjas";

			String s2 = "codingninjas";

			System.out.println(s1 == s2); // Output : true

			s1 = s1 + "article";
			System.out.println(s1);
			System.out.println(s1 == s2); // Output : false
		}
	}

}
