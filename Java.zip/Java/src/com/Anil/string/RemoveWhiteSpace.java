package com.Anil.string;

public class RemoveWhiteSpace {

	static int ind;

	static void removal(String s) {
		for (ind = 0; ind < s.length(); ind++) {
			char ch = s.charAt(ind);
			if (ch != ' ') {
				System.out.print(ch);
			}
		}
	}

	public static void main(String args[]) {
		RemoveWhiteSpace.removal("   Anil Yadav    ");
	}
}

