package com.Anil.string;

import java.util.Scanner;

public class Reverse {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String str = "";
		char ch;
		String A = sc.next();
		for (int i = 0; i < A.length(); i++) {
			ch = A.charAt(i);
			str = ch + str;
		}
		if (str.equals(A)) {
			System.out.println("Yes");
		} else {
			System.out.println("No");
		}

	}
}

