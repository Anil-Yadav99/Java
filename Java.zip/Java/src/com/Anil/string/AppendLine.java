package com.Anil.string;

import java.util.Scanner;

public class AppendLine {

	public static void main(String[] args) {
		/*
		 * Enter your code here. Read input from STDIN. Print output to STDOUT. Your
		 * class should be named Solution.
		 */
//		StringBuilder sb = new StringBuilder("Hello World");
//		StringBuilder sb1 = new StringBuilder("I am a file");
//		StringBuilder sb2 = new StringBuilder("Read me Untill end-of-file");
//		sb.insert(0, "1 ");
//		sb1.insert(0, "2 ");
//		sb2.insert(0, "3 ");
//		System.out.println(sb);
//		System.out.println(sb1);
//		System.out.println(sb2);

		Scanner sc = new Scanner(System.in);
		int i = 1;
		while (sc.hasNext()) {
			String s = sc.nextLine();
			System.out.println(i + " " + s);
			i++;

		}
	}
}