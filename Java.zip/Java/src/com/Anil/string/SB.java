package com.Anil.string;

public class SB {

	public static void main(String[] args) {
		StringBuilder stbu = new StringBuilder();
		// Initial object size
		System.out.println(stbu.capacity());
		StringBuffer stbr = new StringBuffer("Jyoti");
		System.out.println(stbr);
		stbr.append(" Yadav"); // string update
		System.out.println(stbr);
		stbr = new StringBuffer("Vaayu");
		System.out.println(stbr);
	}
}

