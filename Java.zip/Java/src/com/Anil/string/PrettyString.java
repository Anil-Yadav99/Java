package com.Anil.string;

public class PrettyString {
	public static void main(String[] args) {
	float f=215.323f;

	System.out.printf("Formatted String is %.2f", f);
	System.out.print("\n");
	String str = "Jyoti Yadav";
	System.out.printf("Formatted String %.5s", str);
	System.out.print("\n");
	int num = 143;
	System.out.printf("Formatted String %d", num);

}

}
