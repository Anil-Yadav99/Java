package com.Anil.string;

public class SplitString {

	public static void main(String[] args) {
		String str = "HEY MISS JYOTI ANIL YADAV";
		// split string from space
		String[] result = str.split(" ");
		for (int i = 0; i < result.length; i++) {
			System.out.println(result[i]);
		}
	}
}
