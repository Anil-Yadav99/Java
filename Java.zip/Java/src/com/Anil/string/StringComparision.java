package com.Anil.string;

public class StringComparision {

	public static void main(String[] args) {
		String str1 = new String("Jyoti");
		String str2 = new String("Jyoti");
		String str3 = str2;
		System.out.println(str1 == str2);// it compare location of Object hence false
		System.out.println(str2 == str3); // true
		System.out.println(str1.equals(str2)); // true
	}
}
