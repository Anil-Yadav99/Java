package com.Anil.string;

public class StringConcatination {
	public static void main(String[] args) {
		StringBuilder stbu = new StringBuilder();
		// Initial object size
		System.out.println(stbu.capacity());
		String str = "Jyoti";
		System.out.println(str);
		String str1 = new String("MR");
		System.out.println(str1);
		str1 += " Vaayu"; // string update
		String str2 = (str1 + 1);
		System.out.println(str2);
		System.out.println(str1);
	}

}
