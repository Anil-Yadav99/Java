package com.Anil.Interface;

public interface Print {
	void print();

}
