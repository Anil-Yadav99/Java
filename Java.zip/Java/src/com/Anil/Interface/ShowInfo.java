package com.Anil.Interface;

public class ShowInfo implements Print {

	private String name;

	public ShowInfo() {
		super();
	}

	public ShowInfo(String name) {
		super();
		this.name = name;
	}

	@Override
	public void print() {
		System.out.println("This is a interface method");
		System.out.println(this.name);

	}



}
