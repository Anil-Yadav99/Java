package com.Anil.Interface;

public class Runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Print p = new ShowInfo();
		ShowInfo s = new ShowInfo("Jyoti");
		s.print();
		p.print();

	}

}
