package com.Anil.inheritance;

class Vehicle {
	String color;
	int maxspeed;

	public void print() {
		System.out.println("Vehicle Color: " + color);
		System.out.println("Vehicle MaxSpeed: " + maxspeed);
	}
}
