package com.Anil.inheritance;

class VehicleUse {
	public static void main(String[] args) {
		Vehicle v = new Vehicle();
		v.print();
		System.out.println();

		Vehicle v1 = new Car();
		Car c = new Car();
		c.gears = 5;

		// Car class can access the data members and
		// functions of its parent class i.e. Vehicle Class
		v1.color = "Brown";
		v1.print();
		System.out.println();

		c.Carprint();
	}
}