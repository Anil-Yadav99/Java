package com.Anil.inheritance;

class Car extends Vehicle {
	int gears;
	boolean isconvertible;

	// default function
	void Carprint() {
		System.out.println("Car gears: " + gears);
		System.out.println("Is car convertible: " + isconvertible);
	}
}