package com.Anil.classobject;

public class Sqaure {
	private int side;

	public Sqaure(int side) {
		if (side < 0) {
			this.side = -1;
		} else {
			this.side = side;
		}
	}

	public int calculateArea() {
		return (side * side);
	}

	public int calculatePerimeter() {
		return 4 * side;
	}
	public static void main(String[] args) {
		Sqaure s = new Sqaure(5);
		System.out.println(s.calculateArea());
		System.out.println(s.calculatePerimeter());
	}

}
