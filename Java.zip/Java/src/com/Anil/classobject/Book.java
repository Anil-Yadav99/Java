package com.Anil.classobject;

public class Book {
	public void bookName(String name) {
		System.out.println(name);
	}
	public static void main(String[] args) {
		Book b1 = new Book();
		Book b2 = new Book();
		Book b3 = new Book();
		b1.bookName("Art Of Computer Programming");
		b2.bookName("Effective Java");
		b3.bookName("Clean Code");
	}

}
