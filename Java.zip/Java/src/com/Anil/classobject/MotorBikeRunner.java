package com.Anil.classobject;

public class MotorBikeRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MotorBike royal = new MotorBike(100);
		MotorBike honda = new MotorBike(80);
		// royal.start();
		// honda.start();

		// royal.setSpeed(100);
		// int increaseSpeed = royal.getSpeed();
		// royal.howMuch(100);
		System.out.println(royal.getSpeed());
		System.out.println(honda.getSpeed());
		// honda.setSpeed(80);
	}

}
