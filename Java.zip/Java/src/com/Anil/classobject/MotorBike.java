package com.Anil.classobject;

public class MotorBike {
	// STATE
	private int speed;

	MotorBike(int Speed)
	{
		this.speed = Speed;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		if (speed > 0) {
			this.speed = speed;
			// System.out.println(this.speed);
		}

	}

	public void howMuch(int howMuch) {
		this.speed = this.speed + howMuch;
	}
	// BEHAVIOUR
	public void start() {
		System.out.println("Bike Started");
	}
}
