package com.Anil.classobject;

public class Dimension {
	private int feet;
	private int inches;

	public Dimension(int inches) {
		if (inches < 0) {
			this.feet = -1;
			this.inches = -1;
		} else {
			feet = inches / 12;
			inches = inches % 12;
		}
	}

	public int getFeet(int feet) {
		return feet;
	}

	public int getInches(int inches) {
		return inches;
	}

	public static void main(String[] args) {
		Dimension d = new Dimension(-1);
		System.out.println(d.getFeet(25));
		System.out.println(d.getInches(25));
	}

}
