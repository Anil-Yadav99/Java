package com.spring.jdbc.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.spring.jdbc.entities.Student;

public class StudentDaoImpl implements StudentDao {
	private JdbcTemplate jdbcTemplate;
	@Override
	public int insert(Student Student) {
		String Query = "Insert into Student(id,name,city) values(?,?,?)";
		int r = this.jdbcTemplate.update(Query, Student.getId(), Student.getName(), Student.getCity());
		return r;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int change(Student Student) {
		// Update Student
		String Query = "Update Student set Name=?,City=? where ID=?";
		int r = this.jdbcTemplate.update(Query, Student.getName(), Student.getCity(), Student.getId());
		return r;
	}

	@Override
	public int delete(int StudentId) {
		// Delete Student
		String Query = "delete from Student where id=?";
		int r = this.jdbcTemplate.update(Query, StudentId);
		return r;
	}

	@Override
	public Student getStudent(int studentId) {
		// Selecting Single Student
		RowMapper<Student> rowMapper = new RowMapperImpl();
		String Query = "Select * from Student where ID=?";
		Student r = this.jdbcTemplate.queryForObject(Query, rowMapper, studentId);
		return r;
	}

	@Override
	public List<Student> getAllStudents() {
		// selecting multiple Student
		String Query = "Select * from Student";
		List<Student> student = this.jdbcTemplate.query(Query, new RowMapperImpl());
		return student;
	}

}
