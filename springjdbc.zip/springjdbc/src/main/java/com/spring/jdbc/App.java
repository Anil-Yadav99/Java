package com.spring.jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.jdbc.dao.StudentDao;
import com.spring.jdbc.entities.Student;
public class App
{
    public static void main( String[] args )
    {
//        System.out.println( "Hello World!" );
		// Spring JDBC => JdbcTemplate
		ApplicationContext context = new ClassPathXmlApplicationContext("com/spring/jdbc/config.xml");
		JdbcTemplate template = context.getBean("jdbcTemplate", JdbcTemplate.class);

		// insert without Interface
//		String Query = "Insert into Student(id,name,city) values(?,?,?)";

		// fire query
//		template.update(Query, 2, "Jyoti", "Thane");

		StudentDao studentDao = context.getBean("studentDao", StudentDao.class);
		Student student = new Student();

		// Insert Into Student
//		student.setId(2);
//		student.setName("Jyoti");
//		student.setCity("Thane");
//		student.setId(3);
//		student.setName("Yadav");
//		student.setCity("Jaunpur");
//		int result = studentDao.insert(student);
//		System.out.print(result + "Row updated");

		// Update Into Student
//		student.setName("Vaayu");
//		student.setCity("Mumbai");
//		student.setId(1);
//		int result = studentDao.change(student);
//		System.out.print(result + "Row updated");

		// Delete from Student
//		int result = studentDao.delete(3);

		// Select Single Data
//		Student result = studentDao.getStudent(2);
//		System.out.print(result);

		// Select Multiple Data

		List<Student> students = studentDao.getAllStudents();
		for (Student s : students) {
			System.out.println(s);

		}
    }
}
